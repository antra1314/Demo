﻿using LoanPaymentScheduler.Models;
using System;
using System.Collections.Generic;
using System.Web.Mvc;

namespace LoanPaymentScheduler.Controllers
{
    public class LoanDetailsController : Controller
    {
        List<LoanDetails> list;        
        public ActionResult GetDetails()
        {
            return View();
        }

        [HttpPost]
        public ActionResult SetDetails(FormCollection borrowOption, int vehiclePrice=0, int depositAmount=0, DateTime? deliveryDate = null)
        {            
            ViewBag.Title = "Car Loan Report";
            ViewBag.Note = "This calculation includes deduction of £88 arrangement fee & £20 completion fee";
            float amountDuePerMonth = 0;
            int totalMonths = 0;
            List<DateTime> dueDate = new List<DateTime>();
            string borrowOpt = borrowOption["borrowOption"].ToString();
            string errorMessage = string.Empty;
            
            totalMonths = CalculateNoOfMonth(borrowOpt, totalMonths);
            amountDuePerMonth = CalculateAmountDue(amountDuePerMonth, totalMonths, vehiclePrice, depositAmount);         

            int minDeposit = vehiclePrice * 15 / 100;
            if (depositAmount < minDeposit)
            { 
                errorMessage = "Minimum 15% deposit is required";
            }

            if (deliveryDate.HasValue)
            {
                if (totalMonths > 1)
                {
                    for (int i = 1; i <= totalMonths; i++)
                    {

                        dueDate = GetMondays(deliveryDate.Value, totalMonths);

                    }
                }
                else
                {
                    dueDate = GetMondays(deliveryDate.Value, totalMonths);
                }
            }
            if (deliveryDate.HasValue)
            {
                list = new List<LoanDetails>()
                    {
                    // to do
                        new LoanDetails()
                        { deliveryDate = dueDate[0], depositAmount = depositAmount, amountDue = amountDuePerMonth, errorMessage = errorMessage },
                          new LoanDetails()
                        { deliveryDate = dueDate[1], depositAmount = 0, amountDue = amountDuePerMonth, errorMessage = errorMessage },
                          new LoanDetails()
                        { deliveryDate = dueDate[2], depositAmount = 0, amountDue = amountDuePerMonth, errorMessage = errorMessage },
                          new LoanDetails()
                        { deliveryDate = dueDate[3], depositAmount = 0, amountDue = amountDuePerMonth, errorMessage = errorMessage },
                           new LoanDetails()
                        { deliveryDate = dueDate[4], depositAmount = 0, amountDue = amountDuePerMonth, errorMessage = errorMessage },
                            new LoanDetails()
                        { deliveryDate = dueDate[5], depositAmount = 0, amountDue = amountDuePerMonth, errorMessage = errorMessage },
                          new LoanDetails()
                        { deliveryDate = dueDate[6], depositAmount = 0, amountDue = amountDuePerMonth, errorMessage = errorMessage },
                          new LoanDetails()
                        { deliveryDate = dueDate[7], depositAmount = 0, amountDue = amountDuePerMonth, errorMessage = errorMessage },
                          new LoanDetails()
                        { deliveryDate = dueDate[8], depositAmount = 0, amountDue = amountDuePerMonth, errorMessage = errorMessage },
                           new LoanDetails()
                        { deliveryDate = dueDate[9], depositAmount = 0, amountDue = amountDuePerMonth, errorMessage = errorMessage },
                             new LoanDetails()
                        { deliveryDate = dueDate[10], depositAmount = 0, amountDue = amountDuePerMonth, errorMessage = errorMessage }
                    };
            }           
            
            return View(list);
        }

       
        public static List<DateTime> GetMondays(DateTime deliveryDate, int totalMonths)
        {
            List<DateTime> dueDate = new List<DateTime>();
            DateTime nextMonthMonday = new DateTime();
            int intYear = deliveryDate.Year;
            int intMonth = deliveryDate.Month;
            for (int mth = intMonth; mth <= totalMonths; mth++)
            {
                DateTime dt = new DateTime(intYear, mth, 1);
                while (dt.DayOfWeek != DayOfWeek.Monday)
                {
                    dt = dt.AddDays(1);
                }
                nextMonthMonday = dt;
                dueDate.Add(nextMonthMonday);              
            }
            return dueDate;
        }

        public int CalculateNoOfMonth(string borrowOpt, int totalMonths)
        {
            switch (borrowOpt)
            {
                case "2":
                    totalMonths = 24;
                    break;
                case "3":
                    totalMonths = 36;
                    break;
                default:
                    totalMonths = 12;
                    break;
            }
            return totalMonths;
        }

        public float CalculateAmountDue(float amountDuePerMonth, int totalMonths,int vehiclePrice, int depositAmount)
        {
            int arrangementFee = 88;
            int completionFee = 20;
            float amountDue = vehiclePrice - (depositAmount + arrangementFee + completionFee);
            amountDuePerMonth = amountDue / totalMonths;
            return amountDuePerMonth;
        }
    }
}