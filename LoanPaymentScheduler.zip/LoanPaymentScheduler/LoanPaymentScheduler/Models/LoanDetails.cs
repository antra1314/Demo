﻿using System;
using System.ComponentModel.DataAnnotations;

namespace LoanPaymentScheduler.Models
{
    public class LoanDetails
    {
        [Required(ErrorMessage = "Vehicle Price is required")]
        public int vehiclePrice { get; set; }
        [Required(ErrorMessage = "Deposit Amount is required")]
        public int depositAmount { get; set; }
        [Required(ErrorMessage = "Date is required")]
        public DateTime deliveryDate { get; set; }
        public int borrowOption { get; set; }
        public string errorMessage { get; set; }
        public float amountDue { get; set; }
    }
}